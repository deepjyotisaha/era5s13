# Session 13 results — notebook v1, profile smoke

Model 16 × 320, vocab 8,192, 22.5M parameters. Device cuda (Tesla T4).

Acceptance: **12/12**

| run | stack | batch | steps | final train | final val | tokens/s | peak MiB | cost $ |
|---|---|---|---|---|---|---|---|---|
| A | standard | 32 | 122 | 6.7080 | 6.7963 | 54,743 | 4,051 | 0.003 |
| B | midpoint | 32 | 122 | 6.7200 | 6.8100 | 41,612 | 1,328 | 0.004 |
| C | twostream | 32 | 122 | 6.6403 | 6.7279 | 43,291 | 1,165 | 0.004 |
| D | twostream | 96 | 40 | 7.2495 | 7.3196 | 44,683 | 1,808 | 0.003 |

Variant verdict: two-stream trained better: 6.7279 vs 6.8100 nats

Run D batch 96 (step limit), learning rate 1.73e-03.

Largest batch: ordinary 144, midpoint 664, two-stream 912


## Acceptance

- [PASS] A. midpoint (Euler start) gradients == plain autograd, fp64
- [PASS] A. midpoint (plain start) gradients == plain autograd, fp64
- [PASS] A. two-stream gradients == plain autograd, fp64
- [PASS] B. planted dropout bug caught, both stacks
- [PASS] C. rebuilt states within threshold, fp32
- [PASS] C. gradient cosine vs autograd under fp16 autocast
- [PASS] data: 50M-token budget fits the tokenised file
- [PASS] runs: every run finished its step budget
- [PASS] runs: every run's validation loss fell
- [PASS] probe: reversible largest batch > ordinary
- [PASS] probe: reversible memory grows less per layer than ordinary
- [PASS] run D: batch larger than 32
